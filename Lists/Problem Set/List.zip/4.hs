reverse (x:xs) = foldl f [] (x:xs)
	where f = (flip(:))
